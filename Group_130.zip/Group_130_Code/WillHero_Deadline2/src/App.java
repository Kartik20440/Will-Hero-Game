import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import java.io.IOException;

public class App extends Application{
    @Override
    public void start(Stage stage) throws IOException {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
            stage.setTitle("Will Hero");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            stage.setOnCloseRequest(event -> {
                event.consume();
				quit(stage);
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void quit(Stage stage){	
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Quit");
		alert.setHeaderText("You're about to Quit");
		if (alert.showAndWait().get() == ButtonType.OK){
			System.out.println("You successfully exitted the game");
			stage.close();
		} 
	}


    public static void main(String[] args) {
        launch();
    }
}
