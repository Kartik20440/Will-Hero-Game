import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Controller implements Initializable {
    public static controller2 controller2;
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @FXML
    private ImageView myImage1, myImage4, myImage5, myImage6;

    @FXML
    private Button quitbutton;
    
    @FXML
    private BorderPane myBorderPane;

    
    private void imagefade(ImageView i){
        FadeTransition fade1 = new FadeTransition();
        fade1.setNode(i);
        fade1.setDuration(Duration.millis(2500));
        fade1.setCycleCount(1);
        fade1.setFromValue(0);
        fade1.setToValue(1);
        fade1.play();
    }
    
    @Override
    public void initialize(URL arg0, ResourceBundle arg1){        
        imagefade(myImage4);
        imagefade(myImage5);
        imagefade(myImage6);
    }

    public void switchToLoginpage(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToMainPageAction(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToMainPage(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToProduceBy(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ProducedBy.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToSettings(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToIngameSettings(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("IngameSettings.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToIngame(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Ingame2.fxml"));
        root = (Parent) loader.load();
        controller2 = loader.getController();
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToLoadMenu(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("loadmenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void quit(ActionEvent event){
        Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Quit");
		alert.setHeaderText("You are about to Quit!");
		
		if(alert.showAndWait().get() == ButtonType.OK){
			stage = (Stage) myBorderPane.getScene().getWindow();
			System.out.println("You successfully Exitted the game!");
			stage.close();
		}
    }

}