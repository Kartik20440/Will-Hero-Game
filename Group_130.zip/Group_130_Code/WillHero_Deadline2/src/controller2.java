import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class controller2 implements Initializable {
    public static controller2 controller2;
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Rectangle Hero, Queen, Boss;

    @FXML
    private ImageView myImage4, myImage5, myImage6, setting;

    //GREEN ORCS-----------------------------------------------------------------
    @FXML
    private Rectangle Gorc1, Gorc2, Gorc3, Gorc4, Gorc5, Gorc6, Gorc7, Gorc8, Gorc9, Gorc10, Gorc11, Gorc12, Gorc13, Gorc14;
    //---------------------------------------------------------------------------
    //RED ORCS-------------------------------------------------------------------
    @FXML
    private Rectangle Rorc1, Rorc2, Rorc3, Rorc4, Rorc5, Rorc6, Rorc7, Rorc8, Rorc9, Rorc10;
    //---------------------------------------------------------------------------
    //PLATFORMS------------------------------------------------------------------
    @FXML
    private Rectangle Plat1, Plat2, Plat3, Plat4, Plat5, Plat6, Plat7, Plat8, Plat9, Plat10, Plat11,Plat12, Plat13, Plat14, Plat15, Plat16, Plat17, Plat18, Plat19, Plat20, Plat21, Plat22, Plat23, Plat24, Plat25, Plat26, Plat27, Plat28, Plat29, Plat30, Plat31, Plat32, Plat33;
    //---------------------------------------------------------------------------
    //WEAPON CHESTS--------------------------------------------------------------
    @FXML
    private Rectangle Wchest1, Wchest2, Wchest3;
    //---------------------------------------------------------------------------
    //COIN CHESTS----------------------------------------------------------------
    @FXML
    private Rectangle Cchest1, Cchest2, Cchest3, Cchest4;
    //---------------------------------------------------------------------------
    //TNT------------------------------------------------------------------------
    @FXML
    private Rectangle TNT1, TNT2, TNT3;
    //---------------------------------------------------------------------------
    @FXML
    private Button quitbutton, bt1, bt2, revive, end;
    
    @FXML
    private BorderPane myBorderPane, borderPane;

    @FXML
    private Pane MYPANE, mypane2;

    @FXML
    private Text Score, Coins, gameovertext, GO, won, norevive;

    ArrayList<Rectangle> coinChest = new ArrayList<Rectangle>();
    
    Image hero = new Image("Images/hero.png");
    Image plat1 = new Image("Images/Islands1.png");
    Image plat2 = new Image("Images/Islands2.png");
    Image plat3 = new Image("Images/Islands3.png");
    Image plat4 = new Image("Images/Islands4.png");
    Image gorc = new Image("Images/Greenorc.png");
    Image rorc = new Image("Images/Redorc.png");
    Image weaponchest = new Image("Images/WeaponChest.png");
    Image coinchest = new Image("Images/coinChest.png");
    Image tntImage = new Image("Images/TNT.png");
    Image boss = new Image("Images/Boss.png");
    Image queen = new Image("Images/Queen.png");
    Image explode = new Image("Images/explosion.png");

    Rectangle[] Greenorcs;
    Rectangle[] Redorcs;
    Rectangle[] Platforms;
    Rectangle[] Weaponchest;
    Rectangle[] Tnt;

    int HeroDied = 0;
    int BossDied = 0;
    int noRevive = 0;

    private void AllTrans(Node i, int time, int cycle, int x, int y, boolean tf, int delay){
        TranslateTransition transition = new TranslateTransition();
        transition.setNode(i);
        transition.setDuration(Duration.millis(time));
        transition.setCycleCount(cycle);
        transition.setByX(x);
        transition.setByY(y);
        transition.setAutoReverse(tf);
        transition.setDelay(Duration.millis(delay));
        transition.play();
    }
    
    private void imagefade(ImageView i){
        FadeTransition fade1 = new FadeTransition();
        fade1.setNode(i);
        fade1.setDuration(Duration.millis(2500));
        fade1.setCycleCount(1);
        fade1.setFromValue(0);
        fade1.setToValue(1);
        fade1.play();
    }
    
    private void textfade(Text i, int x, int y){
        FadeTransition fade1 = new FadeTransition();
        fade1.setNode(i);
        fade1.setDuration(Duration.millis(200));
        fade1.setCycleCount(1);
        fade1.setFromValue(x);
        fade1.setToValue(y);
        fade1.play();
    }

    public void GroupJump2(){  
        AllTrans(bt1, 100, 1, 0, 200, false, 0);
        AllTrans(bt2, 100, 1, 0, 200, false, 0); 
    }

    public void GroupJumpDown(MouseEvent event){
        if(noRevive == 0){
            if(Integer.parseInt(Coins.getText()) >= 5){
                noRevive = 1;
                AllTrans(GO, 100, 1, 0, -200, false, 0);
                AllTrans(end, 100, 1, 0, 200, false, 0);
                AllTrans(revive, 100, 1, 0, 200, false, 0);
                Coins.setText(Integer.toString(Integer.parseInt(Coins.getText()) - 5));
                HeroDied = 0;
            }
            else if(Integer.parseInt(Coins.getText()) < 5){
                AllTrans(gameovertext, 100, 1, 0, 400, false, 0);
                textfade(gameovertext,0,1);
            }   
        }
        else{
            AllTrans(norevive, 100, 1, 0, 400, false, 0);
        }
    }

    public void GroupJumpDown2(){
        
        AllTrans(bt1, 100, 1, 0, -200, false, 0);
        AllTrans(bt2, 100, 1, 0, -200, false, 0);
        
    }
    private void pushrightOrc(Rectangle i){
        AllTrans(i, 70, 1, 50, 0, false, 0);
    }

    AnimationTimer collisionTimer = new AnimationTimer() {
        @Override
        public void handle(long arg0) {
            collision_orcs();
            collision_platform();
            collision_tnt();
            collision_weaponchest();
            collision_coinChest();
        }
    };
    
    private void HeroDie(){
        AllTrans(GO, 100, 1, 0, 200, false, 0);
        AllTrans(end, 100, 1, 0, -200, false, 0);
        AllTrans(revive, 100, 1, 0, -200, false, 0);
    }
    private void HeroDie2(){
        AllTrans(GO, 100, 1, 0, 200, false, 0);
        AllTrans(end, 100, 1, 0, -200, false, 0);
    }
    private void HeroWon(){
        AllTrans(won, 100, 1, 0, 200, false, 0);
        AllTrans(end, 100, 1, 0, -200, false, 0);
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1){
        Rectangle[] Greenorcs = {Gorc1, Gorc2, Gorc3, Gorc4, Gorc5, Gorc6, Gorc7, Gorc8, Gorc9, Gorc10, Gorc11, Gorc12, Gorc13, Gorc14};
        Rectangle[] Redorcs = {Rorc1, Rorc2, Rorc3, Rorc4, Rorc5, Rorc6, Rorc7, Rorc8, Rorc9, Rorc10};
        Rectangle[] Platforms = {Plat1, Plat2, Plat3, Plat4, Plat5, Plat6, Plat7, Plat8, Plat9, Plat10, Plat11,Plat12, Plat13, Plat14, Plat15, Plat16, Plat17, Plat18, Plat19, Plat20, Plat21,Plat22, Plat23, Plat24, Plat25, Plat26, Plat27, Plat28, Plat29, Plat30, Plat31, Plat32, Plat33};
        Rectangle[] Weaponchest = {Wchest1, Wchest2, Wchest3};
        coinChest.add(Cchest1);
        coinChest.add(Cchest2);
        coinChest.add(Cchest3);
        coinChest.add(Cchest4);
        Rectangle[] Tnt = {TNT1, TNT2, TNT3};
        
        //Filling images in Rectangles
        Hero.setFill(new ImagePattern(hero));
        Queen.setFill(new ImagePattern(queen));
        Boss.setFill(new ImagePattern(boss));
        for(int i=0; i<Greenorcs.length; i++){
            Greenorcs[i].setFill(new ImagePattern(gorc));
        }
        for(int i=0; i<Redorcs.length; i++){
            Redorcs[i].setFill(new ImagePattern(rorc));
        }
        for(int i=0; i<Platforms.length; i++){
            if(i%2 == 0){
                Platforms[i].setFill(new ImagePattern(plat1));
            }
            else if(i%2 !=0 && i%3==0){
                Platforms[i].setFill(new ImagePattern(plat2));
            }
            else if(i%2 !=0 && i%5 ==0){
                Platforms[i].setFill(new ImagePattern(plat3));
            }
            else{
                Platforms[i].setFill(new ImagePattern(plat4));
            }
        }
        for(int i=0; i<Weaponchest.length; i++){
            Weaponchest[i].setFill(new ImagePattern(weaponchest));
        }
        for(int i=0; i<coinChest.size(); i++){
            coinChest.get(i).setFill(new ImagePattern(coinchest));
        }
        for(int i=0; i<Tnt.length; i++){
            Tnt[i].setFill(new ImagePattern(tntImage));
        } 
        for(int i=0; i<Greenorcs.length; i++){
            if(i%2==0){
                AllTrans(Greenorcs[i], 650, -1, 0, -85, true,500);
            }
            else{
                AllTrans(Greenorcs[i], 650, -1, 0, -85, true,600);
            } 
        }
        for(int i=0; i<Redorcs.length; i++){
            if(i%2==0){
                AllTrans(Redorcs[i], 650, -1, 0, -85, true,500);
            }
            else{
                AllTrans(Redorcs[i], 650, -1, 0, -85, true,600);
            }
        }
        
        AllTrans(Hero, 650, -1, 0, -75, true,0);
        AllTrans(Queen, 650, -1,0,-75, true,0);
        AllTrans(Boss, 650, -1, 0, -85, true,500);
        textfade(gameovertext,1,0);
        imagefade(myImage4);
        imagefade(myImage5);
        imagefade(myImage6);
        collisionTimer.start();
    }

    public void collision_platform(){
        Rectangle[] Platforms = {Plat1, Plat2, Plat3, Plat4, Plat5, Plat6, Plat7, Plat8, Plat9, Plat10, Plat11,Plat12, Plat13, Plat14, Plat15, Plat16, Plat17, Plat18, Plat19, Plat20, Plat21,Plat22, Plat23, Plat24, Plat25, Plat26, Plat27, Plat28, Plat29, Plat30, Plat31, Plat32, Plat33};

        //checking if hero is on a island
        if(-1*Hero.getTranslateY() < 1){
            int flag = 0;
            for(int i = 0; i <Platforms.length; i++){
                if(Hero.getX()+Hero.getTranslateX() > Platforms[i].getX()-Hero.getWidth() && Hero.getX()+Hero.getTranslateX() < Platforms[i].getX()+Platforms[i].getWidth()){
                    flag = 1;
                    break;
                }
            }
            if(flag == 0){
                // System.out.println("Hero in Abyss");
                if(HeroDied == 0){
                    HeroDied = 1;
                    AllTrans(Hero, 100, 1, 0, 100, false,0);
                    HeroDie();
                }
            }
        }
    }

    

    public void collision_orcs(){
        Rectangle[] Greenorcs = {Gorc1, Gorc2, Gorc3, Gorc4, Gorc5, Gorc6, Gorc7, Gorc8, Gorc9, Gorc10, Gorc11, Gorc12, Gorc13, Gorc14};
        Rectangle[] Redorcs = {Rorc1, Rorc2, Rorc3, Rorc4, Rorc5, Rorc6, Rorc7, Rorc8, Rorc9, Rorc10};
        Rectangle[] Platforms = {Plat1, Plat2, Plat3, Plat4, Plat5, Plat6, Plat7, Plat8, Plat9, Plat10, Plat11,Plat12, Plat13, Plat14, Plat15, Plat16, Plat17, Plat18, Plat19, Plat20, Plat21,Plat22, Plat23, Plat24, Plat25, Plat26, Plat27, Plat28, Plat29, Plat30, Plat31, Plat32, Plat33};
        
        //checking if Orc is on a island
        for(int j=0; j<Greenorcs.length; j++){
            if(-1*Greenorcs[j].getTranslateY() < 1){
                int flag = 0;
                for(int i = 0; i <Platforms.length; i++){
                        if(Greenorcs[j].getX()+Greenorcs[j].getTranslateX() > Platforms[i].getX()-Greenorcs[j].getWidth() && Greenorcs[j].getX()+Greenorcs[j].getTranslateX() < Platforms[i].getX()+Platforms[i].getWidth()){
                            flag = 1;
                            break;
                        }
                    } 
                if(flag == 0){
                    AllTrans(Greenorcs[j], 100, 1, 0, 100, false,0);
                }
            }
        }
        for(int j=0; j<Redorcs.length; j++){
            if(-1*Redorcs[j].getTranslateY() < 1){
                int flag = 0;
                for(int i = 0; i <Platforms.length; i++){
                        if(Redorcs[j].getX()+Redorcs[j].getTranslateX() > Platforms[i].getX()-Redorcs[j].getWidth() && Redorcs[j].getX()+Redorcs[j].getTranslateX() < Platforms[i].getX()+Platforms[i].getWidth()){
                            flag = 1;
                            break;
                        }
                    } 
                if(flag == 0){
                    // System.out.println("Abyss");
                    AllTrans(Redorcs[j], 100, 1, 0, 100, false,0);
                    
                }
            }
        }
        
        // Checking if hero is under green orc
        for(int i=0; i<Greenorcs.length; i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Greenorcs[i].getX()+Greenorcs[i].getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Greenorcs[i].getX()+Greenorcs[i].getTranslateX()+Greenorcs[i].getWidth()+Hero.getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Greenorcs[i].getTranslateY()) + 3) && ( -1*Hero.getTranslateY() > (-1*(Greenorcs[i].getTranslateY())- 3))){
                    System.out.println("Collision under Orc");
                    AllTrans(Hero, 100, 1, 0, 100, false,0);
                    HeroDie();
                    Greenorcs[i].setY(-500);
                    Greenorcs[i].setX(0);
                }
            }
        }
        // Checking if hero is under red orc
        for(int i=0; i<Redorcs.length; i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Redorcs[i].getX()+Redorcs[i].getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Redorcs[i].getX()+Redorcs[i].getTranslateX()+Redorcs[i].getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Redorcs[i].getTranslateY()) +3) && ( -1*Hero.getTranslateY() > (-1*(Redorcs[i].getTranslateY())-3))){
                    System.out.println("Collision under Orc");
                    AllTrans(Hero, 100, 1, 0, 100,false,0);
                    HeroDie();
                    Redorcs[i].setY(-500);
                    Redorcs[i].setX(0);
                }
            }
        }
        
        //Checking if hero hits Top of Green Orc OR Side of Green Orc
        for(int i=0; i<Greenorcs.length; i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Greenorcs[i].getX()+Greenorcs[i].getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Greenorcs[i].getX()+Greenorcs[i].getTranslateX()+Greenorcs[i].getWidth()+Hero.getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Greenorcs[i].getTranslateY()) + Greenorcs[i].getHeight() + 5) && ( -1*Hero.getTranslateY() > (-1*(Greenorcs[i].getTranslateY()) + Greenorcs[i].getHeight() - 5))){
                    // System.out.println("Hit Orc on Top");
                    Coins.setText(Integer.toString(Integer.parseInt(Coins.getText()) + 2));
                    Greenorcs[i].setY(550);
                    Greenorcs[i].setX(0);
                }
            }
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Greenorcs[i].getX()+Greenorcs[i].getTranslateX()+3 && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Greenorcs[i].getX()+Greenorcs[i].getTranslateX()-3){
                if(-1*Hero.getTranslateY() > -1*Greenorcs[i].getTranslateY() - Hero.getHeight() && -1*Hero.getTranslateY() < -1*Greenorcs[i].getTranslateY() + Greenorcs[i].getHeight()){
                    pushrightOrc(Greenorcs[i]);
                    // System.out.println("Hit green orc on side");
                }   
            } 
        }
        //Checking if hero hits Top of Red Orc OR Side of Red Orc
        for(int i=0; i<Redorcs.length; i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Redorcs[i].getX()+Redorcs[i].getTranslateX()+5 && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Redorcs[i].getX()+Redorcs[i].getTranslateX()-5){
                if(-1*Hero.getTranslateY() > -1*Redorcs[i].getTranslateY() - Hero.getHeight() && -1*Hero.getTranslateY() < -1*Redorcs[i].getTranslateY() + Redorcs[i].getHeight()){
                    // System.out.println("Side hit with red");
                    pushrightOrc(Redorcs[i]);
                    // collisionbetweenOrcs();
                }
            }    
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Redorcs[i].getX()+Redorcs[i].getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Redorcs[i].getX()+Redorcs[i].getTranslateX()+Redorcs[i].getWidth()+Hero.getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Redorcs[i].getTranslateY()) + Redorcs[i].getHeight() + 5) && ( -1*Hero.getTranslateY() > (-1*(Redorcs[i].getTranslateY()) + Redorcs[i].getHeight() - 5))){
                    // System.out.println("Hit Orc on Top");
                    Coins.setText(Integer.toString(Integer.parseInt(Coins.getText()) + 2));
                    Redorcs[i].setY(550);
                    Redorcs[i].setX(0);
                }
            }
        }

        if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Boss.getX()+Boss.getTranslateX()+5 && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Boss.getX()+Boss.getTranslateX()-5){
            if(-1*Hero.getTranslateY() > -1*Boss.getTranslateY() - Hero.getHeight() && -1*Hero.getTranslateY() < -1*Boss.getTranslateY() + Boss.getHeight()){
                pushrightOrc(Boss);
            }   
        } 
        if(Score.getText().equals("112")){
            if(BossDied == 0){
                BossDied = 1;
                AllTrans(Boss, 400, 1, 0, 400, false, 0);
                Boss.setX(0);
                Boss.setY(300);
                HeroWon();
            }
        }
        if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Boss.getX()+Boss.getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Boss.getX()+Boss.getTranslateX()+Boss.getWidth()+Hero.getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Boss.getTranslateY()) + 3) && ( -1*Hero.getTranslateY() > (-1*(Boss.getTranslateY())- 3))){
                    System.out.println("Collision under Boss");
                    AllTrans(Hero, 100, 1, 0, 100, false,0);
                    HeroDie2();
                    Boss.setY(-500);
                    Boss.setX(0);
                }
            }
    }

    public void collision_tnt(){
        Rectangle[] Tnt = {TNT1, TNT2, TNT3};
        //checking for tnt explosion
        for(int i = 0; i < Tnt.length; i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Tnt[i].getX()+Tnt[i].getTranslateX() +5 && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Tnt[i].getX()+Tnt[i].getTranslateX()-5){
                if(((Hero.getTranslateY() > Tnt[i].getTranslateY() && Hero.getTranslateY() < (Tnt[i].getTranslateY() + Tnt[i].getHeight())) || ( (Hero.getTranslateY() +Hero.getHeight() > Tnt[i].getTranslateY() ) && (Hero.getTranslateY() + Hero.getHeight() < Tnt[i].getTranslateY() + Tnt[i].getHeight())))){
                    if(HeroDied == 0){
                        HeroDied = 1;
                        HeroDie();
                        Tnt[i].setX(0);
                        Tnt[i].setY(100);
                    }
                    // System.out.println("Hit TNT on Side");
                }
            }
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Tnt[i].getX()+Tnt[i].getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Tnt[i].getX()+Tnt[i].getTranslateX()+Tnt[i].getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Tnt[i].getTranslateY()) + Tnt[i].getHeight() + 3) && ( -1*Hero.getTranslateY() > (-1*(Tnt[i].getTranslateY()) + Tnt[i].getHeight() - 3))){
                    if(HeroDied == 0){
                        HeroDied = 1;
                        HeroDie();
                        Tnt[i].setX(0);
                        Tnt[i].setY(100);
                    }
                    // System.out.println("Hit TNT on Top");
                }
            }
        }
    }
        
    public void collision_coinChest(){
        // Checking for coin chest collision
        for(int i = 0; i < coinChest.size(); i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < coinChest.get(i).getX()+coinChest.get(i).getTranslateX() +1 && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > coinChest.get(i).getX()+coinChest.get(i).getTranslateX()-1){
                if(((Hero.getTranslateY() > coinChest.get(i).getTranslateY() && Hero.getTranslateY() < (coinChest.get(i).getTranslateY() + coinChest.get(i).getHeight())) || ( (Hero.getTranslateY() +Hero.getHeight() > coinChest.get(i).getTranslateY() ) && (Hero.getTranslateY() + Hero.getHeight() < coinChest.get(i).getTranslateY() + coinChest.get(i).getHeight())))){
                    // System.out.println("Hit Coin chest on Side");
                    coinChest.remove(coinChest.get(i));
                    Coins.setText(Integer.toString(Integer.parseInt(Coins.getText()) + 5));
                }
            }

            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > coinChest.get(i).getX()+coinChest.get(i).getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < coinChest.get(i).getX()+coinChest.get(i).getTranslateX()+coinChest.get(i).getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(coinChest.get(i).getTranslateY()) + coinChest.get(i).getHeight() + 1) && ( -1*Hero.getTranslateY() > (-1*(coinChest.get(i).getTranslateY()) + coinChest.get(i).getHeight() - 1))){
                    // System.out.println("Hit Coin chest on Top");
                    coinChest.remove(coinChest.get(i));
                    Coins.setText(Integer.toString(Integer.parseInt(Coins.getText()) + 5));
                    // coins.setText(Integer.toString(Integer.parseInt(coins.getText()) + 5));  
                }
            } 
        }
    }
        
    public void collision_weaponchest(){
        Rectangle[] Weaponchest = {Wchest1, Wchest2, Wchest3};
        // Checking for Weapon Chest
        
        for(int i = 0; i < Weaponchest.length; i++){
            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Weaponchest[i].getX()+Weaponchest[i].getTranslateX() +5 && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Weaponchest[i].getX()+Weaponchest[i].getTranslateX()-5){
                if(((Hero.getTranslateY() > Weaponchest[i].getTranslateY() && Hero.getTranslateY() < (Weaponchest[i].getTranslateY() + Weaponchest[i].getHeight())) || ( (Hero.getTranslateY() +Hero.getHeight() > Weaponchest[i].getTranslateY() ) && (Hero.getTranslateY() + Hero.getHeight() < Weaponchest[i].getTranslateY() + Weaponchest[i].getHeight())))){
                    // System.out.println("Hit Weapon Chest on Side");
                }
            }

            if(Hero.getX()+Hero.getTranslateX()+Hero.getWidth() > Weaponchest[i].getX()+Weaponchest[i].getTranslateX() && Hero.getX()+Hero.getTranslateX()+Hero.getWidth() < Weaponchest[i].getX()+Weaponchest[i].getTranslateX()+Weaponchest[i].getWidth()){
                if(-1*Hero.getTranslateY() < (-1*(Weaponchest[i].getTranslateY()) + Weaponchest[i].getHeight() + 2) && ( -1*Hero.getTranslateY() > (-1*(Weaponchest[i].getTranslateY()) + Weaponchest[i].getHeight() - 2))){
                    // System.out.println("Hit Weapon Chest on Top");
                }
            }
        }    
    }

 
    
    public void dash(MouseEvent event) throws IOException{
        AllTrans(Hero, 100, 1, 50, 0, false, 0);
        AllTrans(MYPANE, 100, 1, -50, 0, false, 0);
        
        Score.setText(Integer.toString(Integer.parseInt(Score.getText()) + 1));
        // score.setText(Integer.toString(Integer.parseInt(Score.getText()) + 1)); 
        
    }

    public void switchToLoginpage(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToMainPageAction(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToMainPage(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToProduceBy(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ProducedBy.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToSettings(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToIngameSettings(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("IngameSettings.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    // public void switchToIngame(ActionEvent event) throws IOException {
    //     FXMLLoader loader = new FXMLLoader(getClass().getResource("Ingame2.fxml"));
    //     root = (Parent) loader.load();
    //     controller2 = loader.getController();
    //     stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    //     scene = new Scene(root);
    //     stage.setScene(scene);
    //     stage.show();
    // }

    public void switchToIngame(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Ingame2.fxml"));
        root = (Parent) loader.load();
        controller2 = loader.getController();
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToLoadMenu(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("loadmenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToGameOver(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("GameOver.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void quit(ActionEvent event){
        Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Quit");
		alert.setHeaderText("You're about to Quit!");
		
		if(alert.showAndWait().get() == ButtonType.OK){
			stage = (Stage) myBorderPane.getScene().getWindow();
			System.out.println("You successfully Exitted the game!");
			stage.close();
		}
    }

}
