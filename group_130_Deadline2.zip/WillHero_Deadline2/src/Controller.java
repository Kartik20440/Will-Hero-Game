import java.io.IOException;
import java.net.URL;
import javafx.util.Duration;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Controller implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ImageView myImage1;
    @FXML
    private ImageView myImage2;
    @FXML
    private ImageView myImage3;
    @FXML
    private ImageView myImage4;
    @FXML
    private ImageView myImage5;
    @FXML
    private ImageView myImage6;
    @FXML
    private ImageView myImage7;
    @FXML
    private ImageView myImage8;
    @FXML
    private ImageView myImage9;
    @FXML
    private ImageView myImage10;
    @FXML
    private Button quitbutton;
    @FXML
    private BorderPane myBorderPane;
    
    @Override
    public void initialize(URL arg0, ResourceBundle arg1){
        TranslateTransition transition = new TranslateTransition();
        transition.setNode(myImage1);
        transition.setDuration(Duration.millis(650));
        transition.setCycleCount(TranslateTransition.INDEFINITE);
        transition.setByY(-75);
        transition.setAutoReverse(true);
        transition.play();

        TranslateTransition transition2 = new TranslateTransition();
        transition2.setNode(myImage2);
        transition2.setDuration(Duration.millis(650));
        transition2.setCycleCount(TranslateTransition.INDEFINITE);
        transition2.setByY(-75);
        transition2.setAutoReverse(true);
        transition2.setDelay(Duration.millis(500));
        transition2.play();

        TranslateTransition transition3 = new TranslateTransition();
        transition3.setNode(myImage3);
        transition3.setDuration(Duration.millis(650));
        transition3.setCycleCount(TranslateTransition.INDEFINITE);
        transition3.setByY(-75);
        transition3.setAutoReverse(true);
        transition3.setDelay(Duration.millis(600));
        transition3.play();
        
        TranslateTransition transition4 = new TranslateTransition();
        transition4.setNode(myImage7);
        transition4.setDuration(Duration.millis(10000));
        transition4.setCycleCount(TranslateTransition.INDEFINITE);
        transition4.setByX(800);
        transition4.play();

        TranslateTransition transition5 = new TranslateTransition();
        transition5.setNode(myImage8);
        transition5.setDuration(Duration.millis(10000));
        transition5.setCycleCount(TranslateTransition.INDEFINITE);
        transition5.setByX(780);
        transition5.play();

        TranslateTransition transition6 = new TranslateTransition();
        transition6.setNode(myImage9);
        transition6.setDuration(Duration.millis(10000));
        transition6.setCycleCount(TranslateTransition.INDEFINITE);
        transition6.setByX(770);
        transition6.play();

        TranslateTransition transition7 = new TranslateTransition();
        transition7.setNode(myImage10);
        transition7.setDuration(Duration.millis(10000));
        transition7.setCycleCount(TranslateTransition.INDEFINITE);
        transition7.setByX(750);
        transition7.play();

        FadeTransition fade1 = new FadeTransition();
        fade1.setNode(myImage4);
        fade1.setDuration(Duration.millis(2500));
        fade1.setCycleCount(1);
        fade1.setFromValue(0);
        fade1.setToValue(1);
        fade1.play();

        FadeTransition fade2 = new FadeTransition();
        fade2.setNode(myImage5);
        fade2.setDuration(Duration.millis(2500));
        fade2.setCycleCount(1);
        fade2.setFromValue(0);
        fade2.setToValue(1);
        fade2.play();

        FadeTransition fade3 = new FadeTransition();
        fade3.setNode(myImage6);
        fade3.setDuration(Duration.millis(2500));
        fade3.setCycleCount(1);
        fade3.setFromValue(0);
        fade3.setToValue(1);
        fade3.play();

    }

    public void switchToLoginpage(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToMainPageAction(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToMainPage(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToProduceBy(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("ProducedBy.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToSettings(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToIngameSettings(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("IngameSettings.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToIngame(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Ingame.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToLoadMenu(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("loadmenu.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void quit(ActionEvent event){
        Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Quit");
		alert.setHeaderText("You're about to Quit!");
		
		if(alert.showAndWait().get() == ButtonType.OK){
			stage = (Stage) myBorderPane.getScene().getWindow();
			System.out.println("You successfully Exitted the game!");
			stage.close();
		}
    }

}